import { useState } from "react";
import { Shield, ShieldAlert, ShieldCheck, ShieldX, Loader2, Send, ThumbsUp, ThumbsDown, Mail, User, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface AnalysisResult {
  risk_score: number;
  risk_level: string;
  flags: string[];
  tips: string[];
  rule_score: number;
  ml_score: number;
}

const Index = () => {
  const [subject, setSubject] = useState("");
  const [sender, setSender] = useState("");
  const [body, setBody] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [feedbackGiven, setFeedbackGiven] = useState(false);

  const handleScan = async () => {
    if (!body.trim()) {
      toast.error("Please paste the email content to analyze.");
      return;
    }
    setLoading(true);
    setResult(null);
    setFeedbackGiven(false);

    try {
      const { data, error } = await supabase.functions.invoke("analyze", {
        body: { subject, sender, body },
      });

      if (error) throw error;
      setResult(data as AnalysisResult);
    } catch {
      toast.error("Analysis failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleFeedback = async (feedback: "correct" | "incorrect") => {
    if (!result) return;
    try {
      const { error } = await supabase.from("scan_feedback").insert({
        email_subject: subject || null,
        email_sender: sender || null,
        email_body: body,
        predicted_risk_level: result.risk_level,
        predicted_risk_score: result.risk_score,
        user_feedback: feedback,
      });
      if (error) throw error;
      setFeedbackGiven(true);
      toast.success("Thanks for your feedback! It helps us improve.");
    } catch {
      toast.error("Could not save feedback. Please try again.");
    }
  };

  const getRiskColor = (level: string) => {
    if (level === "High Risk") return "text-destructive";
    if (level === "Caution") return "text-[hsl(var(--caution))]";
    return "text-[hsl(var(--safe))]";
  };

  const getRiskIcon = (level: string) => {
    if (level === "High Risk") return <ShieldX className="h-8 w-8 text-destructive" />;
    if (level === "Caution") return <ShieldAlert className="h-8 w-8 text-[hsl(var(--caution))]" />;
    return <ShieldCheck className="h-8 w-8 text-[hsl(var(--safe))]" />;
  };

  const getRiskBg = (level: string) => {
    if (level === "High Risk") return "bg-destructive/10 border-destructive/30";
    if (level === "Caution") return "bg-[hsl(var(--caution))]/10 border-[hsl(var(--caution))]/30";
    return "bg-[hsl(var(--safe))]/10 border-[hsl(var(--safe))]/30";
  };

  const getProgressColor = (score: number) => {
    if (score >= 60) return "[&>div]:bg-destructive";
    if (score >= 30) return "[&>div]:bg-[hsl(var(--caution))]";
    return "[&>div]:bg-[hsl(var(--safe))]";
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center gap-3">
          <Shield className="h-8 w-8 text-primary" />
          <div>
            <h1 className="text-xl font-bold tracking-tight text-foreground font-mono">
              InternShield
            </h1>
            <p className="text-xs text-muted-foreground">
              Fake Internship Offer Detection
            </p>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8 space-y-6">
        {/* Input Section */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Mail className="h-5 w-5 text-primary" />
              Paste Suspicious Email
            </CardTitle>
            <CardDescription>
              Enter the email details below and we'll analyze it for red flags.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="subject" className="flex items-center gap-1.5 text-sm">
                  <FileText className="h-3.5 w-3.5" /> Subject
                </Label>
                <Input
                  id="subject"
                  placeholder="e.g. Congratulations! You've been selected"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="sender" className="flex items-center gap-1.5 text-sm">
                  <User className="h-3.5 w-3.5" /> Sender Email
                </Label>
                <Input
                  id="sender"
                  placeholder="e.g. hr@suspicious-company.com"
                  value={sender}
                  onChange={(e) => setSender(e.target.value)}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="body" className="text-sm">Email Body *</Label>
              <Textarea
                id="body"
                placeholder="Paste the full email content here..."
                className="min-h-[180px] font-mono text-sm"
                value={body}
                onChange={(e) => setBody(e.target.value)}
              />
            </div>
            <Button
              onClick={handleScan}
              disabled={loading || !body.trim()}
              className="w-full sm:w-auto"
              size="lg"
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Scanning…
                </>
              ) : (
                <>
                  <Send className="h-4 w-4" />
                  Scan Email
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Loading */}
        {loading && (
          <Card className="border-primary/30 bg-primary/5">
            <CardContent className="py-10 flex flex-col items-center gap-3">
              <Loader2 className="h-10 w-10 animate-spin text-primary" />
              <p className="text-sm text-muted-foreground font-mono">
                Analyzing email for threats…
              </p>
            </CardContent>
          </Card>
        )}

        {/* Trust Report */}
        {result && !loading && (
          <Card className={`shadow-lg border-2 ${getRiskBg(result.risk_level)}`}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-3 text-lg">
                  {getRiskIcon(result.risk_level)}
                  <span>Trust Report</span>
                </CardTitle>
                <span
                  className={`text-sm font-mono font-bold px-3 py-1 rounded-full border ${getRiskBg(result.risk_level)} ${getRiskColor(result.risk_level)}`}
                >
                  {result.risk_level.toUpperCase()}
                </span>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Risk Score */}
              <div className="space-y-2">
                <div className="flex justify-between items-end">
                  <span className="text-sm font-medium text-muted-foreground">Risk Score</span>
                  <span className={`text-3xl font-mono font-bold ${getRiskColor(result.risk_level)}`}>
                    {result.risk_score}
                    <span className="text-base text-muted-foreground">/100</span>
                  </span>
                </div>
                <Progress value={result.risk_score} className={`h-3 ${getProgressColor(result.risk_score)}`} />
                <div className="flex justify-between text-xs text-muted-foreground font-mono">
                  <span>Safe</span>
                  <span>Caution</span>
                  <span>High Risk</span>
                </div>
              </div>

              {/* Red Flags */}
              {result.flags.length > 0 && (
                <div className="space-y-2">
                  <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
                    <ShieldAlert className="h-4 w-4 text-destructive" />
                    Detected Red Flags
                  </h3>
                  <ul className="space-y-1.5">
                    {result.flags.map((flag, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                        <span className="text-destructive mt-1">•</span>
                        {flag}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {result.flags.length === 0 && (
                <p className="text-sm text-muted-foreground italic">
                  No major red flags detected. The email appears relatively safe.
                </p>
              )}

              {/* Safety Tips */}
              <div className="space-y-2 bg-muted/50 rounded-lg p-4">
                <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
                  <ShieldCheck className="h-4 w-4 text-primary" />
                  Safety Tips
                </h3>
                <ul className="space-y-1.5">
                  {result.tips.map((tip, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <span className="text-primary mt-1">✓</span>
                      {tip}
                    </li>
                  ))}
                </ul>
              </div>

              {/* Feedback */}
              <div className="border-t border-border pt-4">
                {feedbackGiven ? (
                  <p className="text-sm text-muted-foreground text-center font-mono">
                    ✓ Feedback recorded — thank you!
                  </p>
                ) : (
                  <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                    <span className="text-sm text-muted-foreground">Was this analysis accurate?</span>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" onClick={() => handleFeedback("correct")}>
                        <ThumbsUp className="h-4 w-4" />
                        Correct
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => handleFeedback("incorrect")}>
                        <ThumbsDown className="h-4 w-4" />
                        Incorrect
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-border mt-12 py-6 text-center text-xs text-muted-foreground">
        <p className="font-mono">InternShield v1.0 — Protecting students from fake opportunities</p>
      </footer>
    </div>
  );
};

export default Index;
