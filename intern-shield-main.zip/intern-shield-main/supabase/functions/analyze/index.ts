import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

// ── Rule-based detection helpers ──────────────────────────────────────

const URGENT_PHRASES = [
  "act now",
  "immediately",
  "urgent",
  "limited time",
  "don't miss",
  "last chance",
  "hurry",
  "expires today",
  "right away",
  "asap",
  "within 24 hours",
  "offer expires",
  "respond immediately",
  "time sensitive",
  "deadline approaching",
];

const PAYMENT_PHRASES = [
  "registration fee",
  "processing fee",
  "pay",
  "payment",
  "wire transfer",
  "western union",
  "money order",
  "bank account",
  "credit card",
  "deposit",
  "advance fee",
  "training fee",
  "send money",
  "bitcoin",
  "crypto",
  "upfront cost",
  "onboarding fee",
];

const SUSPICIOUS_DOMAINS = [
  "gmail.com",
  "yahoo.com",
  "hotmail.com",
  "outlook.com",
  "aol.com",
  "protonmail.com",
  "yandex.com",
  "mail.com",
  "zoho.com",
  "icloud.com",
];

const TOO_GOOD_PHRASES = [
  "guaranteed placement",
  "no interview",
  "no experience needed",
  "earn.*\\$\\d+",
  "salary.*\\$\\d+.*per hour",
  "work from home",
  "100% remote",
  "no skills required",
  "instant offer",
  "selected for",
];

const PERSONAL_INFO_PHRASES = [
  "social security",
  "ssn",
  "passport",
  "bank details",
  "date of birth",
  "mother's maiden",
  "routing number",
  "account number",
  "identity verification fee",
  "copy of id",
];

interface RuleResult {
  score: number;
  flags: string[];
}

function checkUrgentLanguage(text: string): RuleResult {
  const lower = text.toLowerCase();
  const matched = URGENT_PHRASES.filter((p) => lower.includes(p));
  if (matched.length === 0) return { score: 0, flags: [] };
  // Each match adds 7 points, min 20 when any match
  const score = Math.max(20, Math.min(30, matched.length * 7));
  return {
    score,
    flags: [`Urgent/pressuring language detected: "${matched.slice(0, 3).join('", "')}"`],
  };
}

function checkPaymentRequests(text: string): RuleResult {
  const lower = text.toLowerCase();
  const matched = PAYMENT_PHRASES.filter((p) => lower.includes(p));
  if (matched.length === 0) return { score: 0, flags: [] };
  const score = Math.max(20, Math.min(35, matched.length * 10));
  return {
    score,
    flags: [`Payment/fee requests detected: "${matched.slice(0, 3).join('", "')}"`],
  };
}

function checkSuspiciousDomain(sender: string): RuleResult {
  const lower = sender.toLowerCase();
  const domain = lower.split("@")[1] || "";
  const isSuspicious = SUSPICIOUS_DOMAINS.some((d) => domain === d);
  if (!isSuspicious) return { score: 0, flags: [] };
  return {
    score: 20,
    flags: [`Sender uses a free/personal email domain (@${domain}) instead of a company domain`],
  };
}

function checkTooGoodOffers(text: string): RuleResult {
  const lower = text.toLowerCase();
  const matched = TOO_GOOD_PHRASES.filter((p) => new RegExp(p, "i").test(lower));
  if (matched.length === 0) return { score: 0, flags: [] };
  const score = Math.min(25, matched.length * 8);
  return {
    score,
    flags: ["Offer sounds too good to be true (guaranteed placement, no experience needed, etc.)"],
  };
}

function checkPersonalInfoRequests(text: string): RuleResult {
  const lower = text.toLowerCase();
  const matched = PERSONAL_INFO_PHRASES.filter((p) => lower.includes(p));
  if (matched.length === 0) return { score: 0, flags: [] };
  const score = Math.max(20, Math.min(30, matched.length * 10));
  return {
    score,
    flags: [`Requests sensitive personal information: "${matched.slice(0, 3).join('", "')}"`],
  };
}

function checkGenericGreeting(text: string): RuleResult {
  const genericPattern = /\b(dear candidate|dear applicant|dear student|dear sir\/madam|to whom it may concern)\b/i;
  if (!genericPattern.test(text)) return { score: 0, flags: [] };
  return {
    score: 10,
    flags: ["Uses generic greeting instead of your name"],
  };
}

function checkGrammarIssues(text: string): RuleResult {
  // Simple heuristic: excessive caps, repeated punctuation
  const excessiveCaps = (text.match(/[A-Z]{5,}/g) || []).length;
  const repeatedPunct = (text.match(/[!?]{3,}/g) || []).length;
  const issues = excessiveCaps + repeatedPunct;
  if (issues === 0) return { score: 0, flags: [] };
  return {
    score: Math.min(15, issues * 5),
    flags: ["Poor formatting: excessive capitalization or punctuation detected"],
  };
}

// ── Simulated ML score (placeholder for DistilBERT) ──────────────────

function simulateMLScore(text: string): number {
  const lower = text.toLowerCase();
  let score = 20; // baseline suspicion
  const scamIndicators = [
    "congratulations",
    "selected",
    "offer letter",
    "click here",
    "verify",
    "confirm your",
    "whatsapp",
    "telegram",
  ];
  for (const indicator of scamIndicators) {
    if (lower.includes(indicator)) score += 8;
  }
  return Math.min(100, score);
}

// ── Main analysis ────────────────────────────────────────────────────

function analyzeEmail(subject: string, sender: string, body: string) {
  const fullText = `${subject} ${body}`;

  const urgentResult = checkUrgentLanguage(fullText);
  const paymentResult = checkPaymentRequests(fullText);
  const domainResult = checkSuspiciousDomain(sender);
  const tooGoodResult = checkTooGoodOffers(fullText);
  const personalInfoResult = checkPersonalInfoRequests(fullText);
  const genericGreetingResult = checkGenericGreeting(fullText);
  const grammarResult = checkGrammarIssues(fullText);

  const rules = [urgentResult, paymentResult, domainResult, tooGoodResult, personalInfoResult, genericGreetingResult, grammarResult];

  const ruleScore = rules.reduce((sum, r) => sum + r.score, 0);
  const flags = rules.flatMap((r) => r.flags);
  const mlScore = simulateMLScore(fullText);

  // Weighted: 70% rule-based, 30% ML
  let finalScore = Math.min(100, Math.round(ruleScore * 0.7 + mlScore * 0.3));

  // ── Recall-focused hard rules ──────────────────────────────────────
  // Hard rule: any payment/fee request → automatic High Risk (min 75)
  const hasPayment = paymentResult.score > 0;
  const hasUrgent = urgentResult.score > 0;

  if (hasPayment) {
    finalScore = Math.max(75, finalScore);
    if (!flags.includes("Hard rule: payment/fee request detected — automatic High Risk")) {
      flags.push("Hard rule: payment/fee request detected — automatic High Risk");
    }
  }

  // Combined urgent + payment → ensure High Risk with min 75
  if (hasUrgent && hasPayment) {
    finalScore = Math.max(75, finalScore);
    if (!flags.includes("Combined urgent language + payment request — elevated to High Risk")) {
      flags.push("Combined urgent language + payment request — elevated to High Risk");
    }
  }

  // Recall-focused risk levels (lower thresholds to catch more scams)
  let riskLevel: string;
  if (finalScore >= 70) riskLevel = "High Risk";
  else if (finalScore >= 40) riskLevel = "Caution";
  else riskLevel = "Safe";

  // Safety tips based on risk
  const tips: string[] = [];
  if (riskLevel === "High Risk") {
    tips.push("Do NOT respond to this email or click any links.");
    tips.push("Verify the company through official channels (LinkedIn, company website).");
    tips.push("Report this email to your university's career services.");
    tips.push("Never pay money for an internship opportunity.");
  } else if (riskLevel === "Caution") {
    tips.push("Verify the sender's identity through the company's official website.");
    tips.push("Search for reviews about this company online.");
    tips.push("Ask your career advisor for a second opinion.");
    tips.push("Be cautious about sharing personal information.");
  } else {
    tips.push("This email appears legitimate, but always stay vigilant.");
    tips.push("Research the company before accepting any offer.");
    tips.push("Verify the offer through the company's official HR department.");
  }

  return {
    risk_score: finalScore,
    risk_level: riskLevel,
    flags,
    tips,
    rule_score: ruleScore,
    ml_score: mlScore,
  };
}

// ── Edge function handler ────────────────────────────────────────────

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { subject = "", sender = "", body = "" } = await req.json();

    if (!body || body.trim().length === 0) {
      return new Response(
        JSON.stringify({ error: "Email body is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const result = analyzeEmail(subject, sender, body);

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(
      JSON.stringify({ error: "Failed to analyze email" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
