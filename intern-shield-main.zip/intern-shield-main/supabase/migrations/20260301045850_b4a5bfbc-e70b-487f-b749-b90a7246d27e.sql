
-- Create feedback table for storing user corrections
CREATE TABLE public.scan_feedback (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  email_subject TEXT,
  email_sender TEXT,
  email_body TEXT NOT NULL,
  predicted_risk_level TEXT NOT NULL,
  predicted_risk_score INTEGER NOT NULL,
  user_feedback TEXT NOT NULL CHECK (user_feedback IN ('correct', 'incorrect')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.scan_feedback ENABLE ROW LEVEL SECURITY;

-- Allow anyone to insert feedback (no auth required for this public tool)
CREATE POLICY "Anyone can submit feedback"
  ON public.scan_feedback
  FOR INSERT
  WITH CHECK (true);

-- No one can read feedback from the client (admin only via backend)
CREATE POLICY "No public read access"
  ON public.scan_feedback
  FOR SELECT
  USING (false);
